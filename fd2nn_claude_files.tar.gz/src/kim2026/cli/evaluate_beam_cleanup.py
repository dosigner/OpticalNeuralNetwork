"""Evaluate a trained beam-cleanup D2NN."""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from kim2026.cli.common import apply_runtime_environment, dump_json, load_config
from kim2026.data.dataset import CachedFieldDataset
from kim2026.models.d2nn import BeamCleanupD2NN
from kim2026.models.fd2nn import BeamCleanupFD2NN
from kim2026.optics import propagate_same_window
from kim2026.training.metrics import summarize_metrics
from kim2026.training.targets import apply_receiver_aperture, make_detector_plane_target
from kim2026.utils.seed import set_global_seed


def _collate(batch):
    return {
        "u_vacuum": torch.stack([item["u_vacuum"] for item in batch], dim=0),
        "u_turb": torch.stack([item["u_turb"] for item in batch], dim=0),
        "metadata": [item["metadata"] for item in batch],
    }


def _warmup_receiver_propagation(
    *,
    n: int,
    wavelength_m: float,
    window_m: float,
    distances_m: list[float],
    iterations: int,
    device: torch.device,
) -> None:
    if int(iterations) <= 0:
        return
    field = torch.zeros(1, n, n, dtype=torch.complex64, device=device)
    for _ in range(int(iterations)):
        for distance_m in distances_m:
            _ = propagate_same_window(
                field,
                wavelength_m=wavelength_m,
                window_m=window_m,
                z_m=distance_m,
            )


def _build_eval_model(cfg: dict, *, sample_n: int, device: torch.device) -> torch.nn.Module:
    model_type = str(cfg["model"].get("type", "d2nn"))
    if model_type == "fd2nn":
        dual_2f = cfg["optics"]["dual_2f"]
        model = BeamCleanupFD2NN(
            n=sample_n,
            wavelength_m=float(cfg["optics"]["lambda_m"]),
            window_m=float(cfg["grid"]["receiver_window_m"]),
            num_layers=int(cfg["model"]["num_layers"]),
            layer_spacing_m=float(cfg["model"].get("layer_spacing_m", 0.0)),
            phase_max=float(cfg["model"].get("phase_max", 3.14159265)),
            phase_constraint=str(cfg["model"].get("phase_constraint", "symmetric_tanh")),
            phase_init=str(cfg["model"].get("phase_init", "uniform")),
            phase_init_scale=float(cfg["model"].get("phase_init_scale", 0.1)),
            dual_2f_f1_m=float(dual_2f["f1_m"]),
            dual_2f_f2_m=float(dual_2f["f2_m"]),
            dual_2f_na1=None if dual_2f.get("na1") is None else float(dual_2f["na1"]),
            dual_2f_na2=None if dual_2f.get("na2") is None else float(dual_2f["na2"]),
            dual_2f_apply_scaling=bool(dual_2f.get("apply_scaling", False)),
        )
    else:
        model = BeamCleanupD2NN(
            n=sample_n,
            wavelength_m=float(cfg["optics"]["lambda_m"]),
            window_m=float(cfg["grid"]["receiver_window_m"]),
            num_layers=int(cfg["model"]["num_layers"]),
            layer_spacing_m=float(cfg["model"]["layer_spacing_m"]),
            detector_distance_m=float(cfg["model"]["detector_distance_m"]),
        )
    return model.to(device)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, help="Path to YAML config")
    parser.add_argument("--checkpoint", default=None, help="Optional checkpoint path")
    args = parser.parse_args()

    cfg = load_config(args.config)
    apply_runtime_environment(cfg["runtime"])
    set_global_seed(int(cfg["runtime"]["seed"]), strict_reproducibility=bool(cfg["runtime"]["strict_reproducibility"]))
    from kim2026.viz.beam_plots import save_triptych

    split = str(cfg["evaluation"]["split"])
    dataset = CachedFieldDataset(
        cache_dir=cfg["data"]["cache_dir"],
        manifest_path=cfg["data"]["split_manifest_path"],
        split=split,
    )
    loader = DataLoader(dataset, batch_size=int(cfg["training"].get("eval_batch_size", 32)), shuffle=False, num_workers=0, collate_fn=_collate)
    if len(dataset) == 0:
        raise ValueError(f"dataset split is empty: {split}")

    sample_n = int(dataset[0]["u_turb"].shape[-1])
    requested_device = str(cfg["runtime"].get("device", "cuda")).lower()
    if requested_device == "cpu":
        device = torch.device("cpu")
    else:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_type = str(cfg["model"].get("type", "d2nn"))
    model = _build_eval_model(cfg, sample_n=sample_n, device=device)
    checkpoint_path = Path(args.checkpoint or (Path(cfg["experiment"]["save_dir"]) / "checkpoint.pt"))
    state = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(state["model_state_dict"])
    model.eval()
    if model_type != "fd2nn":
        warmup_distances_m = [float(cfg["model"]["detector_distance_m"])]
        if int(cfg["model"]["num_layers"]) > 1:
            warmup_distances_m.append(float(cfg["model"]["layer_spacing_m"]))
        _warmup_receiver_propagation(
            n=sample_n,
            wavelength_m=float(cfg["optics"]["lambda_m"]),
            window_m=float(cfg["grid"]["receiver_window_m"]),
            distances_m=warmup_distances_m,
            iterations=int(cfg["runtime"].get("fft_warmup_iters", 0)),
            device=device,
        )

    loss_mode = str(cfg["training"]["loss"].get("mode", "intensity"))
    complex_mode = loss_mode == "complex"
    if model_type == "fd2nn":
        total_distance = 0.0
    else:
        total_distance = (model.num_layers - 1) * model.layer_spacing_m + model.detector_distance_m
    receiver_window_m = float(cfg["grid"]["receiver_window_m"])
    aperture_diameter_m = float(cfg["receiver"]["aperture_diameter_m"])
    wavelength_m = float(cfg["optics"]["lambda_m"])

    baseline_summaries = []
    model_summaries = []
    first_triptych = None
    with torch.no_grad():
        for batch in loader:
            u_turb = batch["u_turb"].to(device)
            u_vacuum = batch["u_vacuum"].to(device)
            target = make_detector_plane_target(
                u_vacuum,
                wavelength_m=wavelength_m,
                receiver_window_m=receiver_window_m,
                aperture_diameter_m=aperture_diameter_m,
                total_distance_m=total_distance,
                complex_mode=complex_mode,
            )
            apertured = apply_receiver_aperture(
                u_turb,
                receiver_window_m=receiver_window_m,
                aperture_diameter_m=aperture_diameter_m,
            )
            pred_field = model(apertured)

            if complex_mode:
                baseline_field = apertured if model_type == "fd2nn" else propagate_same_window(
                    apertured, wavelength_m=wavelength_m, window_m=receiver_window_m, z_m=total_distance,
                )
                baseline_summaries.append(summarize_metrics(baseline_field, target, complex_mode=True))
                model_summaries.append(summarize_metrics(pred_field, target, complex_mode=True))
            else:
                baseline = propagate_same_window(
                    apertured, wavelength_m=wavelength_m, window_m=receiver_window_m, z_m=total_distance,
                ).abs().square()
                pred = pred_field.abs().square()
                baseline_summaries.append(summarize_metrics(baseline, target, window_m=receiver_window_m))
                model_summaries.append(summarize_metrics(pred, target, window_m=receiver_window_m))
            if first_triptych is None:
                b_vis = (apertured[0] if complex_mode else baseline[0]).abs().square().detach().cpu()
                p_vis = pred_field[0].abs().square().detach().cpu()
                t_vis = (target[0].abs().square() if complex_mode else target[0]).detach().cpu()
                first_triptych = (b_vis, p_vis, t_vis)

    def _mean_summary(items):
        keys = items[0].keys()
        return {key: float(sum(item[key] for item in items) / len(items)) for key in keys}

    summary = {"baseline": _mean_summary(baseline_summaries), "model": _mean_summary(model_summaries)}
    if bool(cfg["evaluation"].get("save_json", True)):
        dump_json(Path(cfg["experiment"]["save_dir"]) / "evaluation.json", summary)
    if bool(cfg["visualization"].get("save_plots", True)) and first_triptych is not None:
        save_triptych(
            Path(cfg["visualization"]["output_dir"]) / f"evaluation_{split}.png",
            baseline=first_triptych[0],
            prediction=first_triptych[1],
            target=first_triptych[2],
        )


if __name__ == "__main__":
    main()
