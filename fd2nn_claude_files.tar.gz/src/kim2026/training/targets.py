"""Target generation helpers."""

from __future__ import annotations

import torch

from kim2026.optics import propagate_same_window
from kim2026.optics.aperture import circular_aperture


def apply_receiver_aperture(field: torch.Tensor, *, receiver_window_m: float, aperture_diameter_m: float) -> torch.Tensor:
    """Apply the receiver aperture mask while preserving the input rank."""
    n = field.shape[-1]
    mask = circular_aperture(
        n=n,
        window_m=receiver_window_m,
        diameter_m=aperture_diameter_m,
        device=field.device,
    ).to(field.dtype)
    mask_shape = (1,) * max(field.ndim - 2, 0) + tuple(mask.shape)
    return field * mask.reshape(mask_shape)


def make_detector_plane_target(
    vacuum_field: torch.Tensor,
    *,
    wavelength_m: float,
    receiver_window_m: float,
    aperture_diameter_m: float,
    total_distance_m: float,
    complex_mode: bool = False,
) -> torch.Tensor:
    """Propagate the aperture-limited vacuum field to the detector plane.

    If complex_mode=True, returns the complex field directly.
    If complex_mode=False (default), returns intensity |field|^2.
    """
    apertured = apply_receiver_aperture(
        vacuum_field,
        receiver_window_m=receiver_window_m,
        aperture_diameter_m=aperture_diameter_m,
    )
    propagated = propagate_same_window(
        apertured,
        wavelength_m=wavelength_m,
        window_m=receiver_window_m,
        z_m=total_distance_m,
    )
    if complex_mode:
        return propagated
    return propagated.abs().square()
