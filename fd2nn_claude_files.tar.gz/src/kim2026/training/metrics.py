"""Beam-cleanup metrics."""

from __future__ import annotations

import torch

from kim2026.training.losses import beam_radius, encircled_energy_fraction


def gaussian_overlap(pred_intensity: torch.Tensor, target_intensity: torch.Tensor) -> torch.Tensor:
    """Return normalized overlap, higher is better."""
    pred_flat = pred_intensity.reshape(pred_intensity.shape[0], -1)
    target_flat = target_intensity.reshape(target_intensity.shape[0], -1)
    numerator = (pred_flat * target_flat).sum(dim=1)
    denominator = torch.linalg.vector_norm(pred_flat, dim=1) * torch.linalg.vector_norm(target_flat, dim=1)
    return numerator / denominator.clamp_min(1e-12)


def strehl_ratio(pred_intensity: torch.Tensor, target_intensity: torch.Tensor) -> torch.Tensor:
    """Return the peak ratio after unit-energy normalization."""
    pred_norm = pred_intensity / pred_intensity.sum(dim=(-2, -1), keepdim=True).clamp_min(1e-12)
    target_norm = target_intensity / target_intensity.sum(dim=(-2, -1), keepdim=True).clamp_min(1e-12)
    return pred_norm.amax(dim=(-2, -1)) / target_norm.amax(dim=(-2, -1)).clamp_min(1e-12)


# ---------------------------------------------------------------------------
# Complex field metrics
# ---------------------------------------------------------------------------


def complex_overlap(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """Phase-sensitive overlap |<pred, target>| / (||pred|| ||target||). Higher is better."""
    pred_flat = pred.reshape(pred.shape[0], -1)
    target_flat = target.reshape(target.shape[0], -1)
    inner = (pred_flat * target_flat.conj()).sum(dim=1)
    norm_pred = torch.linalg.vector_norm(pred_flat, dim=1)
    norm_target = torch.linalg.vector_norm(target_flat, dim=1)
    return inner.abs() / (norm_pred * norm_target).clamp_min(1e-12)


def phase_rmse(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """Phase RMSE in radians after global phase alignment. Lower is better."""
    from kim2026.training.losses import align_global_phase

    aligned = align_global_phase(pred, target)
    amp_threshold = 0.1 * target.abs().amax(dim=(-2, -1), keepdim=True)
    mask = (target.abs() > amp_threshold) & (aligned.abs() > amp_threshold)
    phase_diff = torch.angle(aligned) - torch.angle(target)
    phase_diff = torch.remainder(phase_diff + torch.pi, 2 * torch.pi) - torch.pi
    masked_sq = (phase_diff.square() * mask).sum(dim=(-2, -1)) / mask.sum(dim=(-2, -1)).clamp_min(1)
    return masked_sq.sqrt()


def amplitude_rmse(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """Normalized RMSE between amplitudes. Lower is better."""
    diff = pred.abs() - target.abs()
    peak = target.abs().amax(dim=(-2, -1), keepdim=True).clamp_min(1e-12)
    return (diff.square().mean(dim=(-2, -1)).sqrt() / peak.squeeze(-1).squeeze(-1))


def summarize_metrics(
    pred: torch.Tensor,
    target: torch.Tensor,
    *,
    window_m: float | None = None,
    complex_mode: bool = False,
) -> dict[str, float]:
    """Summarize core cleanup metrics."""
    if complex_mode:
        pred_i = pred.abs().square()
        target_i = target.abs().square()
        return {
            "complex_overlap": float(complex_overlap(pred, target).mean().item()),
            "phase_rmse_rad": float(phase_rmse(pred, target).mean().item()),
            "amplitude_rmse": float(amplitude_rmse(pred, target).mean().item()),
            "intensity_overlap": float(gaussian_overlap(pred_i, target_i).mean().item()),
            "strehl": float(strehl_ratio(pred_i, target_i).mean().item()),
        }
    pred_intensity = pred
    target_intensity = target
    reference_radius = beam_radius(target_intensity, window_m=window_m)
    pred_encircled = encircled_energy_fraction(pred_intensity, reference_radius=reference_radius, window_m=window_m)
    return {
        "overlap": float(gaussian_overlap(pred_intensity, target_intensity).mean().item()),
        "strehl": float(strehl_ratio(pred_intensity, target_intensity).mean().item()),
        "beam_radius": float(beam_radius(pred_intensity, window_m=window_m).mean().item()),
        "encircled_energy": float(pred_encircled.mean().item()),
    }
