"""Beam-cleanup losses."""

from __future__ import annotations

import torch


def _coordinate_grid(size: int, *, window_m: float | None, device: torch.device, dtype: torch.dtype) -> tuple[torch.Tensor, torch.Tensor]:
    span = float(window_m) if window_m is not None else 2.0
    step = span / size
    coords = (torch.arange(size, device=device, dtype=dtype) - (size // 2)) * step
    yy, xx = torch.meshgrid(coords, coords, indexing="ij")
    return xx, yy


def normalized_overlap_loss(pred_intensity: torch.Tensor, target_intensity: torch.Tensor) -> torch.Tensor:
    """Return 1 - normalized overlap between two intensity maps."""
    pred_flat = pred_intensity.reshape(pred_intensity.shape[0], -1)
    target_flat = target_intensity.reshape(target_intensity.shape[0], -1)
    numerator = (pred_flat * target_flat).sum(dim=1)
    denominator = torch.linalg.vector_norm(pred_flat, dim=1) * torch.linalg.vector_norm(target_flat, dim=1)
    overlap = numerator / denominator.clamp_min(1e-12)
    return (1.0 - overlap).mean()


def beam_radius(intensity: torch.Tensor, *, window_m: float | None = None) -> torch.Tensor:
    """Compute the 1/e^2-equivalent beam radius from second moments."""
    xx, yy = _coordinate_grid(
        intensity.shape[-1],
        window_m=window_m,
        device=intensity.device,
        dtype=intensity.dtype,
    )
    total = intensity.sum(dim=(-2, -1)).clamp_min(1e-12)
    r2 = (intensity * (xx.square() + yy.square())).sum(dim=(-2, -1)) / total
    return torch.sqrt(2.0 * r2.clamp_min(0.0))


def beam_radius_loss(pred_intensity: torch.Tensor, target_intensity: torch.Tensor, *, window_m: float | None = None) -> torch.Tensor:
    """MSE on beam radius."""
    pred_radius = beam_radius(pred_intensity, window_m=window_m)
    target_radius = beam_radius(target_intensity, window_m=window_m)
    return torch.mean((pred_radius - target_radius).square())


def encircled_energy_fraction(
    intensity: torch.Tensor,
    *,
    reference_radius: torch.Tensor,
    window_m: float | None = None,
) -> torch.Tensor:
    """Compute fraction of energy within the provided reference radius."""
    xx, yy = _coordinate_grid(
        intensity.shape[-1],
        window_m=window_m,
        device=intensity.device,
        dtype=intensity.dtype,
    )
    r = torch.sqrt(xx.square() + yy.square())
    mask = r.unsqueeze(0) <= reference_radius.view(-1, 1, 1)
    total = intensity.sum(dim=(-2, -1)).clamp_min(1e-12)
    inside = (intensity * mask.to(intensity.dtype)).sum(dim=(-2, -1))
    return inside / total


def encircled_energy_loss(pred_intensity: torch.Tensor, target_intensity: torch.Tensor, *, window_m: float | None = None) -> torch.Tensor:
    """MSE on encircled energy using target beam radius as the reference radius."""
    reference_radius = beam_radius(target_intensity, window_m=window_m)
    pred_fraction = encircled_energy_fraction(pred_intensity, reference_radius=reference_radius, window_m=window_m)
    target_fraction = encircled_energy_fraction(target_intensity, reference_radius=reference_radius, window_m=window_m)
    return torch.mean((pred_fraction - target_fraction).square())


# ---------------------------------------------------------------------------
# Complex field losses
# ---------------------------------------------------------------------------


def align_global_phase(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """Remove global phase offset between pred and target.

    Returns pred multiplied by exp(-j*alpha) where alpha minimizes
    ||pred*exp(-j*alpha) - target||^2.
    """
    pred_flat = pred.reshape(pred.shape[0], -1)
    target_flat = target.reshape(target.shape[0], -1)
    inner = (pred_flat * target_flat.conj()).sum(dim=1)
    alpha = torch.angle(inner)
    correction = torch.exp(-1j * alpha).to(pred.dtype)
    return pred * correction.reshape(-1, *([1] * (pred.ndim - 1)))


def complex_overlap_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """1 - |<pred, target>| / (||pred|| * ||target||).

    Phase-sensitive normalized overlap, invariant to global phase offset.
    """
    pred_flat = pred.reshape(pred.shape[0], -1)
    target_flat = target.reshape(target.shape[0], -1)
    inner = (pred_flat * target_flat.conj()).sum(dim=1)
    norm_pred = torch.linalg.vector_norm(pred_flat, dim=1)
    norm_target = torch.linalg.vector_norm(target_flat, dim=1)
    overlap = inner.abs() / (norm_pred * norm_target).clamp_min(1e-12)
    return (1.0 - overlap).mean()


def amplitude_mse_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """MSE between amplitudes: mean(||pred| - |target||^2)."""
    return torch.mean((pred.abs() - target.abs()).square())


def complex_field_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    *,
    weights: dict[str, float] | None = None,
) -> torch.Tensor:
    """Composite complex field loss."""
    if weights is None:
        weights = {"complex_overlap": 1.0, "amplitude_mse": 0.5}
    w_overlap = float(weights.get("complex_overlap", 1.0))
    w_amp = float(weights.get("amplitude_mse", 0.5))
    terms = []
    if w_overlap > 0:
        terms.append(w_overlap * complex_overlap_loss(pred, target))
    if w_amp > 0:
        terms.append(w_amp * amplitude_mse_loss(pred, target))
    if not terms:
        return torch.tensor(0.0, device=pred.device, dtype=torch.float32)
    return sum(terms)


def beam_cleanup_loss(
    pred_intensity: torch.Tensor,
    target_intensity: torch.Tensor,
    *,
    window_m: float | None = None,
    weights: dict[str, float] | None = None,
) -> torch.Tensor:
    """Composite beam-cleanup loss."""
    if weights is None:
        weights = {"overlap": 1.0, "radius": 0.25, "encircled": 0.25}
    return (
        float(weights.get("overlap", 1.0)) * normalized_overlap_loss(pred_intensity, target_intensity)
        + float(weights.get("radius", 0.25)) * beam_radius_loss(pred_intensity, target_intensity, window_m=window_m)
        + float(weights.get("encircled", 0.25)) * encircled_energy_loss(pred_intensity, target_intensity, window_m=window_m)
    )
